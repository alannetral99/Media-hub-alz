# MediaHub v0.3 — Android test project

## Build APK using GitHub on a phone
1. Extract this ZIP on your phone.
2. Upload the CONTENTS of the extracted folder to the root of your GitHub repository (not the ZIP itself). Include `.github/workflows/build-apk.yml`; enable hidden files in the file manager if needed.
3. Open the repository's Actions tab.
4. Select "Build MediaHub APK" and choose "Run workflow", or wait for the automatic build after upload.
5. Open the completed workflow run and download the `MediaHub-debug-APK` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Current app capabilities
- Native Android interface and URL validation/basic platform label detection.
- Direct video file download (`.mp4`, `.m4v`, `.webm`) using Android DownloadManager to the public Download folder.

## Limitations
- Page URLs from TikTok/Instagram/Facebook/YouTube are not direct video URLs; this build does not extract their streams.
- Resolution choices are UI placeholders until a permitted source API returns actual media variants.
- Download only content you own or are authorized to download.
