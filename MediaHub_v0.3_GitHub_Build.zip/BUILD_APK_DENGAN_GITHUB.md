# Membuat APK MediaHub tanpa Android Studio di HP

Saya belum dapat mengompilasi APK di sesi ini karena Android SDK, Android build-tools, dan Gradle tidak tersedia. Agar APK tetap dapat dibuat, proyek ini sudah disertai workflow GitHub Actions.

1. Ekstrak ZIP proyek.
2. Buat repository baru di https://github.com/new.
3. Unggah seluruh isi folder proyek ke repository (termasuk folder `.github`).
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build MediaHub APK**, lalu tekan **Run workflow**.
6. Setelah selesai, buka hasil run dan unduh artifact **MediaHub-v0.3-debug-apk**.
7. Ekstrak artifact di HP, lalu buka `app-debug.apk` untuk memasang. Android mungkin meminta izin **Install unknown apps** untuk browser/file manager.

Catatan: APK ini adalah build uji. Saat ini hanya mengunduh URL file video langsung (MP4/M4V/WebM). Tautan halaman TikTok/Instagram/YouTube belum dapat diproses dan pilihan resolusi belum benar-benar memilih stream. Konektor sumber resmi/berizin masih perlu ditambahkan.
