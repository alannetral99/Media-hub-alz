package com.mediahub.downloader

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.URL

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var resolution: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(23, 21, 42)
        window.navigationBarColor = android.graphics.Color.rgb(23, 21, 42)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(15, 14, 28))
        }
        fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = s; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            }
        val white = android.graphics.Color.WHITE
        val muted = android.graphics.Color.rgb(180, 178, 195)
        root.addView(text("MEDIAHUB", 28f, white, true))
        root.addView(text("UNIVERSAL VIDEO DOWNLOADER • v0.3", 11f, muted))
        val gap = View(this).apply { minimumHeight = 26 }
        root.addView(gap)

        root.addView(text("Tempel link video", 16f, white, true))
        urlInput = EditText(this).apply {
            hint = "https://.../video.mp4"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            setSingleLine(true)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(android.graphics.Color.rgb(39, 36, 57))
        }
        root.addView(urlInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })

        val analyze = Button(this).apply {
            text = "ANALISIS LINK"
            setOnClickListener { analyzeUrl() }
        }
        root.addView(analyze, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })

        root.addView(text("Resolusi", 16f, white, true).apply {
            setPadding(0, 24, 0, 6)
        })
        resolution = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Otomatis / kualitas sumber", "1080p", "720p", "480p", "360p"))
        }
        root.addView(resolution)

        val download = Button(this).apply {
            text = "DOWNLOAD KE HP"
            setOnClickListener { startDownload() }
        }
        root.addView(download, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })

        status = text("Siap. Tempel URL video untuk memulai.", 14f, muted)
        status.setPadding(0, 24, 0, 0)
        root.addView(status)
        root.addView(text(
            "Catatan: versi uji ini mengunduh URL file video langsung (mis. MP4) ke folder Download. " +
            "Tautan halaman TikTok/Instagram/YouTube memerlukan konektor resmi/berizin dan belum diekstrak oleh versi ini. " +
            "Pilihan resolusi hanya berlaku bila sumber menyediakan URL varian resolusi; pemilihan otomatis belum dapat mengubah kualitas sumber.",
            12f, muted
        ).apply { setPadding(0, 22, 0, 0) })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun analyzeUrl() {
        val raw = urlInput.text.toString().trim()
        if (raw.isBlank()) { status.text = "Masukkan URL terlebih dahulu."; return }
        try {
            val u = URL(raw)
            if (u.protocol != "https" && u.protocol != "http") throw Exception()
            val host = u.host.lowercase()
            val platform = when {
                "tiktok.com" in host -> "TikTok"
                "instagram.com" in host -> "Instagram"
                "facebook.com" in host || "fb.watch" in host -> "Facebook"
                "youtube.com" in host || "youtu.be" in host -> "YouTube"
                else -> "Sumber web / tautan file"
            }
            val direct = u.path.lowercase().let { it.endsWith(".mp4") || it.endsWith(".m4v") || it.endsWith(".webm") }
            status.text = "Sumber terdeteksi: $platform\n" +
                if (direct) "Tautan tampak seperti file video langsung. Siap diunduh." 
                else "Ini tautan halaman, bukan URL file video langsung. Konektor platform belum tersedia pada build uji ini."
        } catch (_: Exception) { status.text = "URL tidak valid. Periksa kembali tautannya." }
    }

    private fun startDownload() {
        val raw = urlInput.text.toString().trim()
        try {
            val uri = Uri.parse(raw)
            if (uri.scheme != "https" && uri.scheme != "http") throw Exception()
            val path = uri.lastPathSegment ?: ""
            if (!(path.lowercase().endsWith(".mp4") || path.lowercase().endsWith(".m4v") || path.lowercase().endsWith(".webm"))) {
                status.text = "Belum bisa mengunduh tautan halaman. Gunakan URL file video langsung atau integrasikan konektor sumber yang berizin."
                return
            }
            val request = DownloadManager.Request(uri)
                .setTitle(path.ifBlank { "MediaHub video" })
                .setDescription("Diunduh oleh MediaHub")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, path)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Unduhan dimulai. Periksa notifikasi dan folder Download."
        } catch (_: Exception) {
            status.text = "Gagal memulai unduhan. Pastikan URL HTTPS/HTTP valid dan dapat diakses."
        }
    }
}
